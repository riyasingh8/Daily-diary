import test from "node:test";
import assert from "node:assert";
import {
  analyzeDiaryWithMemory,
  recordFeedbackAndCorrection,
  teachMemoryDirectly,
  synthesizeJourneyReflection,
  buildMemoryAwarePrompt,
  generateLocalMemoryAwareResponse,
} from "../src/services/memoryAgent.js";
import { hindsightClient } from "../src/services/hindsightClient.js";

test("MemoryAgent - buildMemoryAwarePrompt structures recalled memories and rules correctly", () => {
  const recalledMemories = [
    {
      id: "mem_rule",
      text: "User has severe migraines from caffeine; never suggest coffee.",
      type: "feedback",
      tags: ["correction", "health"],
    },
    {
      id: "mem_pref",
      text: "User prefers concise bullet points for action items.",
      type: "observation",
      tags: ["preference"],
    },
    {
      id: "mem_exp",
      text: "On 2026-10-25, user launched new open-source portfolio.",
      type: "experience",
      tags: ["achievement"],
    },
  ];

  const prompt = buildMemoryAwarePrompt({
    diaryText: "Feeling a bit sluggish this afternoon while reviewing pull requests.",
    date: "2026-10-28",
    todos: [{ text: "Merge auth PR", done: true }],
    recalledMemories,
  });

  assert.ok(prompt.includes("CRITICAL USER CORRECTIONS & RULES"));
  assert.ok(prompt.includes("User has severe migraines from caffeine"));
  assert.ok(prompt.includes("USER PREFERENCES & ESTABLISHED FACTS"));
  assert.ok(prompt.includes("User prefers concise bullet points"));
  assert.ok(prompt.includes("RELEVANT PAST EXPERIENCES & HISTORY"));
  assert.ok(prompt.includes("Feeling a bit sluggish"));
  assert.ok(prompt.includes("Merge auth PR"));
});

test("MemoryAgent - Continuous Improvement: Agent learns from user correction and adapts response", async () => {
  const testBank = "test_agent_learning_" + Date.now();

  // Day 1: User writes diary about fatigue and drinking coffee
  const day1Diary = "Worked late into the night. Drank 3 cups of coffee. Woke up feeling exhausted.";
  const day1Result = await analyzeDiaryWithMemory({
    diaryText: day1Diary,
    date: "2026-10-25",
    todos: [{ text: "Write documentation", done: true }],
    bankId: testBank,
  });

  assert.ok(day1Result.text.length > 50);

  // User submits a correction / negative constraint:
  // "Doctor says NO coffee after 12pm because it triggers migraines. Keep advice in short bullet points."
  const correctionText =
    "Doctor says NO coffee after 12pm because it triggers migraines. Keep advice in short bullet points.";
  await recordFeedbackAndCorrection({
    bankId: testBank,
    diaryDate: "2026-10-25",
    feedbackText: correctionText,
    isCorrection: true,
  });

  // Verify memory was retained in Hindsight
  const bankMemories = hindsightClient.getMemories(testBank);
  const foundRule = bankMemories.find((m) => m.text.includes("migraines") || m.text.includes("bullet points"));
  assert.ok(foundRule, "Correction was not found in Hindsight bank!");

  // Day 2: User writes about afternoon fatigue again
  const day2Diary = "It is 3 PM and I am feeling a heavy slump. Need something to help me power through my study session.";
  const day2Result = await analyzeDiaryWithMemory({
    diaryText: day2Diary,
    date: "2026-10-26",
    todos: [{ text: "Review calculus notes", done: false }],
    bankId: testBank,
  });

  // Verify that Hindsight recalled the correction memory
  assert.ok(day2Result.recalledMemories.length > 0, "Expected memories to be recalled for Day 2");
  const ruleRecalled = day2Result.recalledMemories.some(
    (m) => m.text.includes("migraines") || m.text.includes("coffee") || m.text.includes("bullet")
  );
  assert.ok(ruleRecalled, "Hindsight failed to recall the user correction on Day 2!");

  // Verify the response honored the correction:
  // 1. Used bullet points
  // 2. Warned / steered clear of caffeine
  // 3. Highlighted the active rule connection
  assert.ok(
    day2Result.text.includes("•") || day2Result.text.includes("-"),
    "Expected response to use bullet-point formatting requested by user"
  );
  assert.ok(
    day2Result.text.toLowerCase().includes("chamomile") ||
      day2Result.text.toLowerCase().includes("water") ||
      day2Result.text.toLowerCase().includes("caffeine"),
    "Expected advice to address caffeine restriction"
  );
  assert.ok(
    day2Result.text.includes("Long-Term Memory Connection") || day2Result.text.includes("Applied Active Rules"),
    "Expected response to note memory grounding"
  );

  // Clean up
  await hindsightClient.deleteBank(testBank);
});

test("MemoryAgent - Tasks are retained as experiences and recalled in future context", async () => {
  const testBank = "test_tasks_retention_" + Date.now();

  // Complete specific goal
  await analyzeDiaryWithMemory({
    diaryText: "Productive day at the office.",
    date: "2026-10-27",
    todos: [
      { text: "Deploy production release v2.0", done: true },
      { text: "Run 10km endurance training", done: true },
    ],
    bankId: testBank,
  });

  const memories = hindsightClient.getMemories(testBank);
  const taskMemory = memories.find((m) => m.text.includes("Deploy production release v2.0"));
  assert.ok(taskMemory, "Expected completed tasks to be retained as an experience in Hindsight");
  assert.strictEqual(taskMemory.type, "experience");

  // Recall by querying about deployment
  const recallRes = await hindsightClient.recall({
    bankId: testBank,
    query: "When did I deploy the production release?",
  });

  assert.ok(recallRes.results.length >= 1);
  assert.ok(recallRes.results[0].text.includes("v2.0"));

  // Clean up
  await hindsightClient.deleteBank(testBank);
});

test("MemoryAgent - synthesizeJourneyReflection returns multi-day trajectory", async () => {
  const testBank = "test_journey_reflect_" + Date.now();

  await teachMemoryDirectly({
    bankId: testBank,
    text: "User is transitioning from junior to senior frontend engineer.",
    type: "observation",
  });

  await analyzeDiaryWithMemory({
    diaryText: "Refactored the state management architecture and reduced render cycles by 40%.",
    date: "2026-10-25",
    todos: [],
    bankId: testBank,
  });

  const reflection = await synthesizeJourneyReflection({
    bankId: testBank,
    query: "What technical growth patterns are evident?",
  });

  assert.ok(reflection.text.includes("Hindsight Longitudinal Reflection"));
  assert.ok(reflection.text.includes("frontend engineer"));

  // Clean up
  await hindsightClient.deleteBank(testBank);
});

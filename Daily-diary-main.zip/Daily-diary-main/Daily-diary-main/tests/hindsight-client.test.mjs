import test from "node:test";
import assert from "node:assert";
import { HindsightClient } from "../src/services/hindsightClient.js";

test("HindsightClient - retain() stores memory with correct schema and metadata", async () => {
  const client = new HindsightClient({ preferLocal: true });
  const bankId = "test_bank_retain_" + Date.now();

  const result = await client.retain({
    bankId,
    content: "Alice is training for a marathon on Sunday morning.",
    type: "experience",
    metadata: { date: "2026-10-28", category: "fitness" },
    tags: ["running", "marathon", "fitness"],
  });

  assert.strictEqual(result.success, true);
  assert.ok(result.item.id.startsWith("mem_"));
  assert.strictEqual(result.item.type, "experience");
  assert.strictEqual(result.item.text, "Alice is training for a marathon on Sunday morning.");
  assert.strictEqual(result.item.metadata.category, "fitness");
  assert.deepStrictEqual(result.item.tags, ["running", "marathon", "fitness"]);
  assert.ok(result.item.entities.includes("marathon") || result.item.entities.includes("running"));

  // Clean up
  await client.clearMemories(bankId);
});

test("HindsightClient - recall() retrieves relevant memories based on semantic and keyword overlap", async () => {
  const client = new HindsightClient({ preferLocal: true });
  const bankId = "test_bank_recall_" + Date.now();

  await client.retain({
    bankId,
    content: "User experiences migraines triggered by drinking coffee late in the day.",
    type: "observation",
    tags: ["health", "caffeine"],
  });

  await client.retain({
    bankId,
    content: "User attended a mathematics lecture and felt confident.",
    type: "experience",
    tags: ["study"],
  });

  // Query specifically matching caffeine and health
  const queryResult = await client.recall({
    bankId,
    query: "feeling fatigued, should I have an afternoon coffee?",
    budget: "mid",
  });

  assert.ok(queryResult.results.length >= 1);
  const topMatch = queryResult.results[0];
  assert.ok(
    topMatch.text.toLowerCase().includes("migraines") || topMatch.text.toLowerCase().includes("coffee"),
    `Expected migraine/coffee memory to rank top, got: ${topMatch.text}`
  );

  // Clean up
  await client.clearMemories(bankId);
});

test("HindsightClient - Strict Bank Isolation: Bank A memories are hidden from Bank B", async () => {
  const client = new HindsightClient({ preferLocal: true });
  const bankA = "user_akash_personal_" + Date.now();
  const bankB = "user_sarah_work_" + Date.now();

  await client.retain({
    bankId: bankA,
    content: "Confidential Personal Note: Planning surprise anniversary trip to Japan.",
    type: "experience",
    tags: ["personal", "secret"],
  });

  await client.retain({
    bankId: bankB,
    content: "Sarah is leading the Q4 Kubernetes deployment project.",
    type: "experience",
    tags: ["work", "k8s"],
  });

  // Recall from Bank B searching for Japan / anniversary
  const bankBRecall = await client.recall({
    bankId: bankB,
    query: "anniversary trip to Japan surprise",
    budget: "high",
  });

  // None of Bank A's memories should leak into Bank B
  for (const m of bankBRecall.results) {
    assert.strictEqual(m.text.includes("anniversary trip"), false, "Security violation: Bank A memory leaked into Bank B!");
  }

  // Recall from Bank A searching for Kubernetes
  const bankARecall = await client.recall({
    bankId: bankA,
    query: "Kubernetes deployment project",
    budget: "high",
  });

  for (const m of bankARecall.results) {
    assert.strictEqual(m.text.includes("Kubernetes"), false, "Security violation: Bank B memory leaked into Bank A!");
  }

  // Inspection isolation
  const bankAMemories = client.getMemories(bankA);
  const bankBMemories = client.getMemories(bankB);
  assert.strictEqual(bankAMemories.length, 1);
  assert.strictEqual(bankBMemories.length, 1);
  assert.ok(bankAMemories[0].text.includes("Japan"));
  assert.ok(bankBMemories[0].text.includes("Kubernetes"));

  // Clean up
  await client.deleteBank(bankA);
  await client.deleteBank(bankB);
});

test("HindsightClient - patchMemory() invalidates and edits memories", async () => {
  const client = new HindsightClient({ preferLocal: true });
  const bankId = "test_bank_patch_" + Date.now();

  const retainRes = await client.retain({
    bankId,
    content: "User prefers morning meetings at 9 AM.",
    type: "observation",
  });
  const memId = retainRes.item.id;

  // Verify it is recalled initially
  let recall = await client.recall({ bankId, query: "morning meetings time" });
  assert.strictEqual(recall.results.length, 1);

  // Invalidate memory via PATCH
  const patchRes = await client.patchMemory({
    bankId,
    memoryId: memId,
    patch: { state: "invalidated" },
  });
  assert.strictEqual(patchRes.success, true);

  // Invalidated memories must be excluded from recall
  recall = await client.recall({ bankId, query: "morning meetings time" });
  assert.strictEqual(recall.results.length, 0);

  // Edit memory content and restore to valid state
  await client.patchMemory({
    bankId,
    memoryId: memId,
    patch: {
      text: "User prefers afternoon meetings after 2 PM only.",
      state: "valid",
    },
  });

  recall = await client.recall({ bankId, query: "afternoon meetings" });
  assert.strictEqual(recall.results.length, 1);
  assert.strictEqual(recall.results[0].text, "User prefers afternoon meetings after 2 PM only.");

  // Clean up
  await client.clearMemories(bankId);
});

test("HindsightClient - reflect() synthesizes long-term context over memories", async () => {
  const client = new HindsightClient({ preferLocal: true });
  const bankId = "test_bank_reflect_" + Date.now();

  await client.retain({
    bankId,
    content: "Day 1: Struggling with focus and sleep hygiene.",
    type: "experience",
    metadata: { date: "2026-10-20" },
  });

  await client.retain({
    bankId,
    content: "Day 5: Completed 5k jog and meditating for 10 minutes daily.",
    type: "experience",
    metadata: { date: "2026-10-25" },
  });

  await client.retain({
    bankId,
    content: "User responds best to gentle accountability and milestone praise.",
    type: "observation",
  });

  const reflection = await client.reflect({
    bankId,
    query: "How has my wellness trajectory evolved over the past week?",
    budget: "mid",
  });

  assert.ok(reflection.text.length > 50);
  assert.ok(reflection.text.includes("Hindsight Longitudinal Reflection"));
  assert.ok(reflection.text.includes("gentle accountability"));

  // Clean up
  await client.clearMemories(bankId);
});

test("HindsightClient - Persistence survives across separate client instances", async () => {
  const bankId = "test_bank_persistence_" + Date.now();

  // Instance 1 creates memory
  const client1 = new HindsightClient({ preferLocal: true });
  await client1.retain({
    bankId,
    content: "Persistent observation: User completed AWS Certified Solutions Architect exam.",
    type: "world",
  });

  // Instance 2 connects to same bank
  const client2 = new HindsightClient({ preferLocal: true });
  const memories = client2.getMemories(bankId);
  assert.strictEqual(memories.length, 1);
  assert.strictEqual(memories[0].text, "Persistent observation: User completed AWS Certified Solutions Architect exam.");

  const recall = await client2.recall({ bankId, query: "AWS certification" });
  assert.strictEqual(recall.results.length, 1);

  // Clean up
  await client2.deleteBank(bankId);
});

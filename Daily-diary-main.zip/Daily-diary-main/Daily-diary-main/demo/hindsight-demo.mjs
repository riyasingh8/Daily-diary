/**
 * Hindsight AI Memory - Working Live Demonstration
 *
 * Demonstrates:
 * 1. Persistent memory retention and recall using official Hindsight protocols.
 * 2. Continuous learning from corrections: agent dramatically improves response on Day 2.
 * 3. Strict memory bank isolation between different users / projects.
 * 4. Deep reflection across historical interactions.
 *
 * Run with:
 *   agy-node demo/hindsight-demo.mjs
 */

import { HindsightClient } from "../src/services/hindsightClient.js";
import {
  analyzeDiaryWithMemory,
  recordFeedbackAndCorrection,
} from "../src/services/memoryAgent.js";

const separator = "=".repeat(70);
const subSeparator = "-".repeat(70);

function printHeader(title) {
  console.log(`\n${separator}`);
  console.log(`🧠 ${title}`);
  console.log(`${separator}\n`);
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

async function runDemonstration() {
  const client = new HindsightClient();
  const demoBank = "demo_user_alex_" + Date.now();
  const workBank = "demo_user_work_" + Date.now();

  printHeader("HINDSIGHT AI MEMORY: CONTINUOUS LEARNING DEMONSTRATION");
  console.log(`Target Memory Bank: "${demoBank}"`);
  console.log(`Checking connection to Hindsight engine...`);

  const conn = await client.testConnection(demoBank);
  console.log(`Status: ${conn.message}`);
  console.log(`Active Mode: [${conn.mode.toUpperCase()}]`);

  // -------------------------------------------------------------
  // STEP 1: DAY 1 - Initial Interaction without prior memory
  // -------------------------------------------------------------
  console.log(`\n${subSeparator}`);
  console.log(`📍 STEP 1: DAY 1 (2026-10-25) - Baseline Interaction`);
  console.log(`${subSeparator}`);

  const day1Text =
    "Worked until 1:30 AM preparing client slides. Downed 4 cups of strong coffee to push through. My head is throbbing and I feel restless and completely exhausted.";
  console.log(`User writes diary entry:`);
  console.log(`"${day1Text}"\n`);

  console.log(`⚡ Agent queries Hindsight: client.recall(bankId="${demoBank}")`);
  const day1Recall = await client.recall({
    bankId: demoBank,
    query: day1Text,
  });
  console.log(`Recalled memories: ${day1Recall.results.length} (New user, clean bank)\n`);

  const day1Result = await analyzeDiaryWithMemory({
    diaryText: day1Text,
    date: "2026-10-25",
    todos: [{ text: "Finish client presentation deck", done: true }],
    bankId: demoBank,
  });

  console.log(`🤖 Agent Response (Day 1):`);
  console.log(day1Result.text);

  console.log(`\n💾 Hindsight retains Day 1 diary & completed tasks into bank "${demoBank}".`);
  let memories = client.getMemories(demoBank);
  console.log(`Current memory count in bank: ${memories.length}`);

  await sleep(1000);

  // -------------------------------------------------------------
  // STEP 2: Continuous Learning from User Feedback / Correction
  // -------------------------------------------------------------
  console.log(`\n${subSeparator}`);
  console.log(`📍 STEP 2: USER CORRECTION & TEACHING (Continuous Improvement)`);
  console.log(`${subSeparator}`);

  const correction =
    "My neurologist says STRICTLY NO coffee or caffeine after 12 PM due to chronic migraines! Also, please keep all guidance in short bullet points.";
  console.log(`User gives corrective feedback:`);
  console.log(`"${correction}"\n`);

  console.log(`⚡ Retaining correction into Hindsight (type: "observation", tag: "correction")...`);
  await recordFeedbackAndCorrection({
    bankId: demoBank,
    diaryDate: "2026-10-25",
    feedbackText: correction,
    isCorrection: true,
  });

  memories = client.getMemories(demoBank);
  console.log(`✓ Memory Bank updated. Total memories: ${memories.length}`);
  const rule = memories.find((m) => m.tags?.includes("correction"));
  console.log(`  - Newly Stored Rule ID: ${rule.id}`);
  console.log(`  - Content: "${rule.text}"`);

  await sleep(1000);

  // -------------------------------------------------------------
  // STEP 3: DAY 2 - Memory-Aware Response Adapts to Correction
  // -------------------------------------------------------------
  console.log(`\n${subSeparator}`);
  console.log(`📍 STEP 3: DAY 2 (2026-10-26) - Memory-Augmented Interaction`);
  console.log(`${subSeparator}`);

  const day2Text =
    "It is 3:30 PM and I am hitting an overwhelming energy crash before my final review meeting. I need an energy boost right now.";
  console.log(`User writes new diary entry:`);
  console.log(`"${day2Text}"\n`);

  console.log(`⚡ Agent queries Hindsight: client.recall(bankId="${demoBank}", query="${day2Text}")`);
  const day2Recall = await client.recall({
    bankId: demoBank,
    query: day2Text,
  });

  console.log(`Found ${day2Recall.results.length} relevant memories:`);
  day2Recall.results.forEach((m, idx) => {
    console.log(`  [${idx + 1}] [${m.type.toUpperCase()}] ${m.text}`);
  });

  console.log(`\nGenerating personalized response with recalled context...`);
  const day2Result = await analyzeDiaryWithMemory({
    diaryText: day2Text,
    date: "2026-10-26",
    todos: [{ text: "Attend final review meeting", done: false }],
    bankId: demoBank,
  });

  console.log(`\n🤖 Agent Response (Day 2 - Powered by Hindsight):`);
  console.log(day2Result.text);

  console.log(`\n✨ Notice how the agent's behavior adapted:`);
  console.log(`  1. Recognized the 3:30 PM time and STRICTLY avoided recommending coffee.`);
  console.log(`  2. Recalled the neurologist's warning regarding chronic migraines.`);
  console.log(`  3. Formatted suggestions in concise bullet points as requested.`);
  console.log(`  4. Maintained continuity from Day 1's late-night client slide preparation.`);

  await sleep(1000);

  // -------------------------------------------------------------
  // STEP 4: Bank Isolation Verification
  // -------------------------------------------------------------
  console.log(`\n${subSeparator}`);
  console.log(`📍 STEP 4: MEMORY BANK ISOLATION TEST`);
  console.log(`${subSeparator}`);
  console.log(`Switching context to separate work bank: "${workBank}"`);

  await client.retain({
    bankId: workBank,
    content: "Team sprint retrospective: Frontend migration to Vite completed successfully.",
    type: "experience",
  });

  const isolatedRecall = await client.recall({
    bankId: workBank,
    query: "coffee caffeine migraine neurology",
  });

  console.log(`Querying "${workBank}" for "caffeine migraine neurology"...`);
  console.log(`Results returned: ${isolatedRecall.results.length}`);
  if (isolatedRecall.results.length === 0) {
    console.log(`✓ VERIFIED: Zero data leakage. Bank "${workBank}" has no access to "${demoBank}".`);
  } else {
    console.error(`❌ VIOLATION: Memory leaked across banks!`);
  }

  // -------------------------------------------------------------
  // STEP 5: Longitudinal Reflection
  // -------------------------------------------------------------
  console.log(`\n${subSeparator}`);
  console.log(`📍 STEP 5: HINDSIGHT DEEP REFLECTION`);
  console.log(`${subSeparator}`);
  console.log(`Running client.reflect() to synthesize journey insights...`);

  const reflection = await client.reflect({
    bankId: demoBank,
    query: "What health and productivity adjustments has the user made?",
  });

  console.log(reflection.text);

  // Cleanup demo banks
  await client.deleteBank(demoBank);
  await client.deleteBank(workBank);

  printHeader("DEMONSTRATION COMPLETED SUCCESSFULLY!");
}

runDemonstration().catch((err) => {
  console.error("Demonstration encountered error:", err);
  process.exit(1);
});

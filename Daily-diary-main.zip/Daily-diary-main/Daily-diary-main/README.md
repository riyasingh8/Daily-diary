# AI Life Organizer (Powered by Vectorize Hindsight AI Memory)

> Bridging productivity and self-reflection with long-term, adaptive AI agent memory.

**AI Life Organizer** is a memory-powered smart diary and productivity suite. Unlike conventional journals or stateless "chat-history RAG" wrappers, this application uses [Vectorize Hindsight](https://hindsight.vectorize.io/) long-term agent memory. It actively learns from your past entries, completed tasks, health conditions, and explicit corrections—adapting its tone, advice, and motivation over time.

---

## ✨ Features

- 🧠 **Hindsight Persistent Agent Memory**: Remembers your struggles, ongoing goals, habits, and preferences across sessions and calendar dates.
- 🔄 **Continuous Learning from Feedback & Corrections**: If you teach the agent a negative constraint (e.g. *"I quit caffeine due to migraines; keep advice in short bullet points"*), Hindsight stores this as an active rule, ensuring future analyses strictly honor it.
- 🛡️ **Strict Memory Bank Isolation**: Multi-bank partitioning (`bank_id`) ensures memories from personal entries, work projects, or different user profiles never leak into one another.
- 🔍 **Interactive Memory Bank Inspector**: Inspect all stored memory units, filter by type (`world`, `experience`, `observation`, `feedback`), search keyword/semantic tags, edit text, or invalidate outdated memories via `PATCH`.
- 🔮 **Hindsight Deep Longitudinal Reflection**: Uses Hindsight's `reflect()` reasoning loop to synthesize multi-week personal trajectories, emotional continuity, and habit streaks.
- 🎬 **Interactive Working Demonstration**: Built-in 3-day simulation showing how the agent's advice adapts before and after receiving user corrections.
- ⚡ **Neo-Manga / Neubrutalist UI**: High-contrast borders, solid drop shadows, and responsive dark-theme design.
- 📅 **Dynamic Calendar & Tasks**: Align daily thoughts with task completions, automatically retained as experiences in Hindsight.

---

## 🏛️ Architecture & Memory Workflow

Hindsight transforms the stateless LLM loop into an adaptive, personalized agent:

```
┌────────────────────────────────────────────────────────┐
│                   User Action                          │
│  (Writes Diary, Checks Tasks, or Submits Feedback)     │
└───────────────────────────┬────────────────────────────┘
                            │
                            ▼
 1. RECALL PHASE [POST /v1/default/banks/{bank}/memories/recall]
    Multi-path retrieval fetches relevant user facts,
    prior experiences, and critical corrections/rules.
                            │
                            ▼
 2. AUGMENTED PROMPT SYNTHESIS
    Combines today's diary + active rules + past history
    into a structured memory context.
                            │
                            ▼
 3. REASONING & RESPONSE GENERATION
    LLM generates tailored insights strictly adhering
    to user-taught constraints.
                            │
                            ▼
 4. RETENTION PHASE [POST /v1/default/banks/{bank}/memories]
    Automatically retains today's diary & task milestones
    as structured experiences and observations.
                            │
                            ▼
 5. CURATION & REFLECTION [PATCH / DELETE / reflect]
    User can invalidate memories, edit facts, or synthesize
    longitudinal reflections across weeks.
```

### The 4 Hindsight Memory Types

1. **`experience`**: Direct chronological logs of events, diary reflections, and completed to-do items.
2. **`observation`**: Inferred or consolidated patterns, behavioral tendencies, and user preferences.
3. **`feedback` / `correction`**: Critical rules and negative constraints (e.g. dietary limits, formatting preferences) that override default LLM guidance.
4. **`world`**: Objective facts about the user's life (e.g. occupation, key relationships, milestone dates).

---

## 🔧 Environment Variables & Configuration

Copy `.env.example` to `.env`:

```bash
cp .env.example .env
```

| Variable | Default | Purpose |
| :--- | :--- | :--- |
| `VITE_HINDSIGHT_API_URL` / `HINDSIGHT_API_URL` | `https://api.hindsight.vectorize.io` | Endpoint for Hindsight Cloud or self-hosted server (`http://localhost:8888`) |
| `VITE_HINDSIGHT_API_KEY` / `HINDSIGHT_API_KEY` | *(optional for local)* | API key for authenticating with Hindsight Cloud |
| `VITE_DEFAULT_BANK_ID` / `HINDSIGHT_DEFAULT_BANK_ID` | `diary_user_default` | Default isolated memory bank identifier |
| `VITE_GEMINI_API_KEY` / `GEMINI_API_KEY` | *(optional)* | Google Gemini API key for response generation |

> **Note on Offline Resilience**: If no Hindsight API credentials are provided, the application automatically operates in **High-Fidelity Local Persistent Memory mode**. It persists memory banks locally with the exact same 4-layer schema, semantic/keyword ranking, bank isolation, and curation APIs, ensuring zero friction out of the box!

---

## 🧪 Testing the Memory Workflow

The project includes an automated test suite verifying storage, retrieval, persistence, isolation, and memory-aware responses:

```bash
# Run all Hindsight and Agent tests
agy-node --test tests/hindsight-client.test.mjs tests/memory-agent.test.mjs

# Or with system node:
node --test tests/hindsight-client.test.mjs tests/memory-agent.test.mjs
```

### Test Suite Coverage

- `tests/hindsight-client.test.mjs`:
  - `retain()`: Validates schema, metadata, tags, and entity extraction.
  - `recall()`: Tests multi-factor ranking (semantic, keyword, type boost, recency).
  - **Strict Bank Isolation**: Verifies Bank A memories are completely invisible to Bank B.
  - `patchMemory()`: Validates invalidation (`state: 'invalidated'`) and editing of memories.
  - `reflect()`: Validates longitudinal synthesis over historical units.
  - Persistence: Verifies memory survival across independent client instances.
- `tests/memory-agent.test.mjs`:
  - Memory-augmented prompt generation.
  - Continuous learning from feedback and corrections.
  - Automatic task retention as experiences.
  - Journey reflection synthesis.

---

## 🎬 Running the Working Demonstration

A standalone CLI demonstration is included to showcase the agent learning and improving over simulated days:

```bash
agy-node demo/hindsight-demo.mjs

# Or with system node:
node demo/hindsight-demo.mjs
```

### What the Demo Shows

1. **Day 1 (Baseline)**: User records a late-night coding session with 4 cups of coffee and headache. AI provides standard advice.
2. **User Correction**: User teaches Hindsight: *"My neurologist says STRICTLY NO coffee after 12pm due to chronic migraines! Keep advice in concise bullet points."*
3. **Day 2 (Memory-Powered)**: User writes about an afternoon energy slump. The agent recalls the migraine/caffeine rule and bullet-point preference—warning against coffee, suggesting non-caffeinated hydration, and formatting concisely.
4. **Bank Isolation**: Confirms a separate work bank has zero access to personal medical rules.
5. **Reflection**: Demonstrates `client.reflect()` synthesizing multi-day growth.

---

## 🚀 Running the Frontend Application

```bash
# Install dependencies
npm install

# Start Vite dev server
npm run dev
```

Open `http://localhost:5173` in your browser.

- Click **"🧠 Memory Bank"** in the top-right to inspect, edit, invalidate, or add memories.
- Click **"⚙️ Settings"** to test your connection or update API keys.
- Click **"✨ Interactive Hindsight Learning Demo"** to run the 3-day scenario right in the browser!

---

## 📄 License

MIT. Built with [Vectorize Hindsight](https://github.com/vectorize-io/hindsight).

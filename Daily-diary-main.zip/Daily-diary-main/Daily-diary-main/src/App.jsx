import { useEffect, useState } from "react";

import DiaryEditor from "./components/DiaryEditor";
import AIResponse from "./components/AIResponse";
import CalendarPicker from "./components/CalendarPicker";
import TodoList from "./components/TodoList";
import Clock from "./components/Clock";
import MemoryInspector from "./components/MemoryInspector";
import SettingsModal from "./components/SettingsModal";
import DemoTour from "./components/DemoTour";

import { analyzeDiary } from "./utils/gemini";
import {
  getDay,
  saveDiary,
  saveAI,
  saveTodos,
  getAIMemories,
} from "./utils/storage";
import { getAppConfig } from "./utils/config";
import { hindsightClient } from "./services/hindsightClient";

export default function App() {
  const today = new Date().toISOString().slice(0, 10);

  const [date, setDate] = useState(today);
  const [diary, setDiary] = useState("");
  const [aiResult, setAiResult] = useState("");
  const [recalledMemories, setRecalledMemories] = useState([]);
  const [todos, setTodos] = useState([]);
  const [loading, setLoading] = useState(false);
  const [loadingStage, setLoadingStage] = useState("");
  const [isDataLoaded, setIsDataLoaded] = useState(false);

  // Hindsight Memory State
  const [bankId, setBankId] = useState(() => getAppConfig().bankId);
  const [showInspector, setShowInspector] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [memoryRefreshSignal, setMemoryRefreshSignal] = useState(0);

  useEffect(() => {
    setIsDataLoaded(false); // Block auto-save during loading
    const data = getDay(date);

    setDiary(data?.diary || "");
    setAiResult(data?.ai || "");
    setRecalledMemories(data?.aiMemories || getAIMemories(date) || []);
    setTodos(data?.todos || []);

    setTimeout(() => setIsDataLoaded(true), 50);
  }, [date]);

  useEffect(() => {
    if (!isDataLoaded || loading) return;

    const delayDebounceFn = setTimeout(() => {
      saveDiary(date, diary);
    }, 500);

    return () => clearTimeout(delayDebounceFn);
  }, [diary, date, isDataLoaded, loading]);

  const handleUpdateTodos = (newTodos) => {
    setTodos(newTodos);
    if (isDataLoaded) {
      saveTodos(date, newTodos);
    }
  };

  const handleBankChange = (newBank) => {
    if (newBank === "create_new") {
      const name = window.prompt("Enter new memory bank ID (e.g. user_work, project_alpha):");
      if (name && name.trim()) {
        const cleanName = name.trim().toLowerCase().replace(/[^a-z0-9_-]/g, "_");
        setBankId(cleanName);
        hindsightClient.defaultBankId = cleanName;
      }
    } else {
      setBankId(newBank);
      hindsightClient.defaultBankId = newBank;
    }
    setMemoryRefreshSignal((prev) => prev + 1);
  };

  async function analyze() {
    if (!diary.trim()) return;
    setLoading(true);
    setLoadingStage("🧠 Recalling relevant long-term memories from Hindsight...");

    try {
      const result = await analyzeDiary(diary, {
        date,
        todos,
        bankId,
        returnFullResult: true,
        onProgress: (stage, message) => {
          setLoadingStage(message);
        },
      });

      const responseText = typeof result === "string" ? result : result.text;
      const memoriesUsed = result.recalledMemories || [];

      setAiResult(responseText);
      setRecalledMemories(memoriesUsed);
      saveAI(date, responseText, memoriesUsed);
      setMemoryRefreshSignal((prev) => prev + 1);
    } catch (err) {
      console.error(err);
      alert("AI is not responding. Please try again later.");
    } finally {
      setLoading(false);
      setLoadingStage("");
    }
  }

  return (
    <div className="container">
      {/* Neo-Manga App Header */}
      <header className="card-header">
        <div className="header-top-row">
          <div>
            <h1>AI Life Organizer</h1>
            <span className="header-badge">🧠 Powered by Hindsight AI Memory</span>
          </div>

          <div className="header-actions">
            <button
              type="button"
              className={`btn-header-action ${showInspector ? "active" : ""}`}
              onClick={() => setShowInspector(!showInspector)}
              title="Toggle Memory Bank Inspector"
            >
              🧠 Memory Bank
            </button>
            <button
              type="button"
              className="btn-header-action"
              onClick={() => setShowSettings(true)}
              title="Configure Hindsight & LLM"
            >
              ⚙️ Settings
            </button>
          </div>
        </div>

        {/* Bank & Profile Quick Switcher */}
        <div className="bank-quickbar">
          <span className="bank-quickbar-label">Current Bank:</span>
          <span className="bank-pill">📦 {bankId}</span>
          <button
            type="button"
            className="btn-link"
            onClick={() => handleBankChange("create_new")}
          >
            + New Bank
          </button>
        </div>
      </header>

      {/* Interactive Demonstration Tour */}
      <DemoTour
        bankId={bankId}
        onDemoComplete={() => setMemoryRefreshSignal((prev) => prev + 1)}
      />

      <Clock />

      {/* Settings Modal */}
      <SettingsModal
        isOpen={showSettings}
        onClose={() => setShowSettings(false)}
        onSettingsSaved={(cfg) => {
          setBankId(cfg.bankId);
          setMemoryRefreshSignal((prev) => prev + 1);
        }}
      />

      {/* Expandable Memory Bank Inspector */}
      {showInspector && (
        <MemoryInspector
          bankId={bankId}
          onBankChange={handleBankChange}
          refreshSignal={memoryRefreshSignal}
          onMemoryUpdated={() => setMemoryRefreshSignal((prev) => prev + 1)}
        />
      )}

      <div className="main-grid">
        <CalendarPicker date={date} setDate={setDate} />

        <DiaryEditor
          value={diary}
          onChange={setDiary}
          onSubmit={analyze}
        />

        {loading && (
          <div className="card loading-card">
            <p className="animate-pulse font-bold text-accent">
              {loadingStage || "🤖 AI is reading your day..."}
            </p>
          </div>
        )}

        <AIResponse
          result={aiResult}
          recalledMemories={recalledMemories}
          bankId={bankId}
          date={date}
          onMemoryUpdated={() => setMemoryRefreshSignal((prev) => prev + 1)}
        />

        <TodoList
          date={date}
          todos={todos}
          setTodos={handleUpdateTodos}
        />
      </div>
    </div>
  );
}

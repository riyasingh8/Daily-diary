/**
 * Configuration manager for Hindsight and LLM credentials.
 * Reads environment variables first, falling back to local persistent overrides.
 * Never hardcodes secrets.
 */

const SETTINGS_KEY = "hindsight_diary_settings_v1";

export function getAppConfig() {
  const env = (typeof import.meta !== "undefined" && import.meta.env) || (typeof process !== "undefined" && process.env) || {};

  let saved = {};
  if (typeof window !== "undefined" && window.localStorage) {
    try {
      saved = JSON.parse(window.localStorage.getItem(SETTINGS_KEY)) || {};
    } catch {
      saved = {};
    }
  }

  return {
    hindsightUrl:
      saved.hindsightUrl ||
      env.VITE_HINDSIGHT_API_URL ||
      env.HINDSIGHT_API_URL ||
      "https://api.hindsight.vectorize.io",
    hindsightKey:
      saved.hindsightKey ||
      env.VITE_HINDSIGHT_API_KEY ||
      env.HINDSIGHT_API_KEY ||
      "",
    geminiKey:
      saved.geminiKey ||
      env.VITE_GEMINI_API_KEY ||
      env.GEMINI_API_KEY ||
      "",
    bankId:
      saved.bankId ||
      env.VITE_DEFAULT_BANK_ID ||
      env.HINDSIGHT_DEFAULT_BANK_ID ||
      "diary_user_default",
  };
}

export function saveAppConfig(patch) {
  if (typeof window === "undefined" || !window.localStorage) return;
  const current = getAppConfig();
  const updated = {
    ...current,
    ...patch,
  };
  window.localStorage.setItem(SETTINGS_KEY, JSON.stringify(updated));
}

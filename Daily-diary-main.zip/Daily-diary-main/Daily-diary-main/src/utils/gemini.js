/**
 * gemini.js - Bridge between diary UI and memory-aware AI services.
 * Integrates Hindsight AI memory while preserving backward compatibility.
 */

import { analyzeDiaryWithMemory } from "../services/memoryAgent.js";

/**
 * Analyze diary with Hindsight persistent memory
 *
 * @param {string} text - Diary content
 * @param {Object} [options]
 * @param {string} [options.date] - Date in YYYY-MM-DD
 * @param {Array} [options.todos] - Tasks of the day
 * @param {string} [options.bankId] - Target memory bank
 * @param {Function} [options.onProgress] - Loading state callback
 * @param {boolean} [options.returnFullResult] - Whether to return full object
 * @returns {Promise<string|{text: string, recalledMemories: Array, mode: string}>}
 */
export async function analyzeDiary(text, options = {}) {
  const date = options.date || new Date().toISOString().slice(0, 10);
  const todos = options.todos || [];
  const bankId = options.bankId;
  const onProgress = options.onProgress || (() => {});

  const result = await analyzeDiaryWithMemory({
    diaryText: text,
    date,
    todos,
    bankId,
    onProgress,
  });

  // If full result object requested
  if (options.returnFullResult) {
    return result;
  }

  // Return text string for backward compatibility
  return result.text;
}

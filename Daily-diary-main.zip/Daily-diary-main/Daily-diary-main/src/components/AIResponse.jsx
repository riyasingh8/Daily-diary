import { useState } from "react";
import { recordFeedbackAndCorrection } from "../services/memoryAgent";

export default function AIResponse({
  result,
  recalledMemories = [],
  bankId,
  date,
  onMemoryUpdated = () => {},
}) {
  const [showMemories, setShowMemories] = useState(false);
  const [feedbackSent, setFeedbackSent] = useState(false);
  const [feedbackSuccessMsg, setFeedbackSuccessMsg] = useState("");
  const [showCorrectionInput, setShowCorrectionInput] = useState(false);
  const [correctionText, setCorrectionText] = useState("");
  const [submittingFeedback, setSubmittingFeedback] = useState(false);

  if (!result) return null;

  async function handleThumbsUp() {
    setSubmittingFeedback(true);
    try {
      await recordFeedbackAndCorrection({
        bankId,
        diaryDate: date,
        feedbackText: "User marked analysis as helpful and well-aligned with goals.",
        isCorrection: false,
      });
      setFeedbackSent(true);
      setFeedbackSuccessMsg("Feedback stored in Hindsight! The agent reinforces this style.");
      onMemoryUpdated();
      setTimeout(() => setFeedbackSuccessMsg(""), 4000);
    } catch (err) {
      console.error(err);
    } finally {
      setSubmittingFeedback(false);
    }
  }

  async function handleCorrectionSubmit() {
    if (!correctionText.trim()) return;
    setSubmittingFeedback(true);
    try {
      await recordFeedbackAndCorrection({
        bankId,
        diaryDate: date,
        feedbackText: correctionText.trim(),
        isCorrection: true,
      });
      setFeedbackSent(true);
      setFeedbackSuccessMsg("Correction learned by Hindsight! Future responses will strictly follow this.");
      setCorrectionText("");
      setShowCorrectionInput(false);
      onMemoryUpdated();
      setTimeout(() => setFeedbackSuccessMsg(""), 5000);
    } catch (err) {
      console.error(err);
    } finally {
      setSubmittingFeedback(false);
    }
  }

  return (
    <div className="card ai ai-card-wrapper">
      <div className="ai-card-topbar">
        <h2>Overview 🌙</h2>
        <span className="badge-hindsight">🧠 Hindsight Memory Active</span>
      </div>

      <pre className="ai-content">{result}</pre>

      {/* Recalled Memories Breakdown */}
      {recalledMemories && recalledMemories.length > 0 && (
        <div className="recalled-memories-box">
          <button
            type="button"
            className="btn-toggle-memories"
            onClick={() => setShowMemories(!showMemories)}
          >
            {showMemories ? "▲ Hide" : "▼ Show"} {recalledMemories.length} Memories Recalled for this Response
          </button>

          {showMemories && (
            <div className="recalled-list">
              {recalledMemories.map((m, idx) => (
                <div key={m.id || idx} className="recalled-item">
                  <span className={`tag-type tag-${m.type || "experience"}`}>
                    {m.type || "experience"}
                  </span>
                  <span className="recalled-text">{m.text}</span>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Continuous Learning & Feedback Bar */}
      <div className="feedback-section">
        <p className="feedback-label">How was this analysis? (Teaches Hindsight)</p>
        <div className="feedback-buttons">
          <button
            type="button"
            className="btn-feedback btn-thumb"
            disabled={submittingFeedback}
            onClick={handleThumbsUp}
          >
            👍 Helpful
          </button>
          <button
            type="button"
            className="btn-feedback btn-correct"
            disabled={submittingFeedback}
            onClick={() => setShowCorrectionInput(!showCorrectionInput)}
          >
            ✏️ Correct / Teach AI
          </button>
        </div>

        {feedbackSuccessMsg && (
          <div className="feedback-success-banner">
            ✨ {feedbackSuccessMsg}
          </div>
        )}

        {showCorrectionInput && (
          <div className="correction-form">
            <input
              type="text"
              placeholder="e.g. I quit caffeine due to migraines; keep advice in short bullet points..."
              value={correctionText}
              onChange={(e) => setCorrectionText(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleCorrectionSubmit()}
            />
            <button
              type="button"
              className="btn-save-correction"
              onClick={handleCorrectionSubmit}
              disabled={submittingFeedback || !correctionText.trim()}
            >
              {submittingFeedback ? "Saving..." : "Save Rule to Hindsight"}
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

import { useState, useEffect } from "react";
import { hindsightClient } from "../services/hindsightClient";
import { teachMemoryDirectly, synthesizeJourneyReflection } from "../services/memoryAgent";

export default function MemoryInspector({
  bankId,
  onBankChange,
  refreshSignal,
  onMemoryUpdated,
}) {
  const [memories, setMemories] = useState([]);
  const [filterType, setFilterType] = useState("all");
  const [searchQuery, setSearchQuery] = useState("");
  const [newMemoryText, setNewMemoryText] = useState("");
  const [newMemoryType, setNewMemoryType] = useState("observation");
  const [loading, setLoading] = useState(false);
  const [connectionStatus, setConnectionStatus] = useState(null);
  const [editingId, setEditingId] = useState(null);
  const [editText, setEditText] = useState("");
  const [reflectionText, setReflectionText] = useState("");
  const [reflecting, setReflecting] = useState(false);
  const [notice, setNotice] = useState("");

  useEffect(() => {
    loadMemories();
    checkConnection();
  }, [bankId, refreshSignal]);

  async function checkConnection() {
    const status = await hindsightClient.testConnection(bankId);
    setConnectionStatus(status);
  }

  function loadMemories() {
    const list = hindsightClient.getMemories(bankId);
    setMemories(list);
  }

  async function handleAddMemory() {
    if (!newMemoryText.trim()) return;
    setLoading(true);
    try {
      await teachMemoryDirectly({
        bankId,
        text: newMemoryText.trim(),
        type: newMemoryType,
        tags: ["user_taught", newMemoryType],
      });
      setNewMemoryText("");
      showNotice("Memory successfully retained into Hindsight!");
      loadMemories();
      if (onMemoryUpdated) onMemoryUpdated();
    } catch (err) {
      showNotice(`Error adding memory: ${err.message}`);
    } finally {
      setLoading(false);
    }
  }

  async function handleToggleInvalidate(memory) {
    const nextState = memory.state === "invalidated" ? "valid" : "invalidated";
    await hindsightClient.patchMemory({
      bankId,
      memoryId: memory.id,
      patch: { state: nextState },
    });
    showNotice(nextState === "invalidated" ? "Memory invalidated (ignored during recall)." : "Memory restored to valid state.");
    loadMemories();
    if (onMemoryUpdated) onMemoryUpdated();
  }

  async function handleSaveEdit(id) {
    if (!editText.trim()) return;
    await hindsightClient.patchMemory({
      bankId,
      memoryId: id,
      patch: { text: editText.trim() },
    });
    setEditingId(null);
    setEditText("");
    showNotice("Memory content updated.");
    loadMemories();
    if (onMemoryUpdated) onMemoryUpdated();
  }

  async function handleClearBank() {
    const confirmed = window.confirm(`Are you sure you want to clear all memories for bank "${bankId}"?`);
    if (!confirmed) return;
    await hindsightClient.clearMemories(bankId);
    showNotice(`All memories in bank "${bankId}" have been cleared.`);
    loadMemories();
    if (onMemoryUpdated) onMemoryUpdated();
  }

  async function handleReflect() {
    setReflecting(true);
    try {
      const res = await synthesizeJourneyReflection({
        bankId,
        query: "Analyze my recent habits, emotional continuity, goals, and recurring themes across my entries.",
      });
      setReflectionText(res.text);
    } catch (err) {
      setReflectionText(`Reflection error: ${err.message}`);
    } finally {
      setReflecting(false);
    }
  }

  function showNotice(msg) {
    setNotice(msg);
    setTimeout(() => setNotice(""), 4000);
  }

  // Filter memories
  const filtered = memories.filter((m) => {
    if (filterType !== "all" && m.type !== filterType) {
      if (filterType === "correction" && !(m.type === "feedback" || m.tags?.includes("correction"))) {
        return false;
      } else if (filterType !== "correction") {
        return false;
      }
    }
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const inText = m.text.toLowerCase().includes(q);
      const inTags = m.tags && m.tags.some((t) => t.toLowerCase().includes(q));
      return inText || inTags;
    }
    return true;
  });

  const availableBanks = hindsightClient.listLocalBanks();
  const validCount = memories.filter((m) => m.state !== "invalidated").length;
  const observationCount = memories.filter((m) => m.type === "observation" || m.type === "feedback").length;

  return (
    <div className="card memory-inspector-card">
      <div className="inspector-header">
        <div className="title-row">
          <h2>🧠 Hindsight Memory Bank</h2>
          {connectionStatus && (
            <span
              className={`connection-pill ${
                connectionStatus.connected ? "connected" : "local-mode"
              }`}
              title={connectionStatus.message}
            >
              ● {connectionStatus.mode === "cloud"
                ? "Hindsight Cloud"
                : connectionStatus.mode === "local_server"
                ? "Local Hindsight Server"
                : "Local Persistent Bank"}
            </span>
          )}
        </div>
        <p className="inspector-subtitle">
          Auditable long-term memory with bank isolation, continuous learning, and curation.
        </p>
      </div>

      {notice && <div className="inspector-notice">✨ {notice}</div>}

      {/* Bank Isolation Switcher */}
      <div className="bank-switcher-box">
        <label className="bank-label">Active Memory Bank:</label>
        <div className="bank-input-group">
          <select
            value={bankId}
            onChange={(e) => onBankChange(e.target.value)}
            className="bank-select"
          >
            {availableBanks.map((b) => (
              <option key={b} value={b}>
                {b}
              </option>
            ))}
            <option value="create_new">+ Add New Memory Bank...</option>
          </select>
          <button
            type="button"
            className="btn-reflect"
            onClick={handleReflect}
            disabled={reflecting || memories.length === 0}
          >
            {reflecting ? "Reflecting..." : "🔮 Reflect on Bank"}
          </button>
        </div>
      </div>

      {/* Reflection View if active */}
      {reflectionText && (
        <div className="reflection-output-card">
          <div className="reflection-topbar">
            <h3>🔮 Hindsight Deep Reflection</h3>
            <button
              type="button"
              className="btn-close-reflection"
              onClick={() => setReflectionText("")}
            >
              ✕ Close
            </button>
          </div>
          <pre className="reflection-content">{reflectionText}</pre>
        </div>
      )}

      {/* Teach AI Memory Input */}
      <div className="teach-memory-box">
        <h3>Teach AI a Preference or Rule</h3>
        <div className="teach-inputs">
          <input
            type="text"
            placeholder="e.g. I work best when taking 5-min walk breaks; don't suggest late-night study."
            value={newMemoryText}
            onChange={(e) => setNewMemoryText(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && handleAddMemory()}
          />
          <select
            value={newMemoryType}
            onChange={(e) => setNewMemoryType(e.target.value)}
            className="type-select"
          >
            <option value="observation">Preference / Habit (observation)</option>
            <option value="world">Fact about Life (world)</option>
            <option value="experience">Milestone (experience)</option>
          </select>
          <button
            type="button"
            className="btn-add-memory"
            onClick={handleAddMemory}
            disabled={loading || !newMemoryText.trim()}
          >
            {loading ? "Retaining..." : "Retain"}
          </button>
        </div>
      </div>

      {/* Stats and Filter Controls */}
      <div className="memories-toolbar">
        <div className="stats-pills">
          <span className="pill">Total: {memories.length}</span>
          <span className="pill pill-active">Active: {validCount}</span>
          <span className="pill pill-pref">Preferences: {observationCount}</span>
        </div>

        <div className="filter-controls">
          <div className="filter-buttons">
            <button
              className={`btn-filter ${filterType === "all" ? "active" : ""}`}
              onClick={() => setFilterType("all")}
            >
              All
            </button>
            <button
              className={`btn-filter ${filterType === "experience" ? "active" : ""}`}
              onClick={() => setFilterType("experience")}
            >
              Experiences
            </button>
            <button
              className={`btn-filter ${filterType === "observation" ? "active" : ""}`}
              onClick={() => setFilterType("observation")}
            >
              Observations
            </button>
            <button
              className={`btn-filter ${filterType === "correction" ? "active" : ""}`}
              onClick={() => setFilterType("correction")}
            >
              Corrections
            </button>
            <button
              className={`btn-filter ${filterType === "world" ? "active" : ""}`}
              onClick={() => setFilterType("world")}
            >
              Facts
            </button>
          </div>

          <input
            type="text"
            className="search-input"
            placeholder="Search memories..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
      </div>

      {/* Memory Units List */}
      <div className="memory-units-container">
        {filtered.length === 0 ? (
          <div className="empty-memories">
            <p>No memories found in bank "{bankId}" matching criteria.</p>
            <p className="empty-hint">Write a diary entry or teach the memory bank above to retain knowledge!</p>
          </div>
        ) : (
          filtered.map((mem) => {
            const isInvalid = mem.state === "invalidated";
            const isEditing = editingId === mem.id;

            return (
              <div
                key={mem.id}
                className={`memory-unit-item ${isInvalid ? "invalidated" : ""} type-${mem.type}`}
              >
                <div className="unit-header">
                  <div className="unit-badges">
                    <span className={`tag-type tag-${mem.type}`}>{mem.type}</span>
                    {isInvalid && <span className="tag-invalidated">INVALIDATED</span>}
                    {mem.metadata?.date && (
                      <span className="tag-date">📅 {mem.metadata.date}</span>
                    )}
                  </div>
                  <div className="unit-actions">
                    <button
                      type="button"
                      className="btn-unit-action"
                      onClick={() => {
                        if (isEditing) {
                          setEditingId(null);
                        } else {
                          setEditingId(mem.id);
                          setEditText(mem.text);
                        }
                      }}
                      title="Edit text"
                    >
                      {isEditing ? "Cancel" : "✏️ Edit"}
                    </button>
                    <button
                      type="button"
                      className={`btn-unit-action ${isInvalid ? "restore" : "invalidate"}`}
                      onClick={() => handleToggleInvalidate(mem)}
                      title={isInvalid ? "Restore memory" : "Invalidate memory"}
                    >
                      {isInvalid ? "↺ Restore" : "✕ Invalidate"}
                    </button>
                  </div>
                </div>

                {isEditing ? (
                  <div className="edit-unit-form">
                    <textarea
                      rows="3"
                      value={editText}
                      onChange={(e) => setEditText(e.target.value)}
                    />
                    <button
                      type="button"
                      className="btn-save-edit"
                      onClick={() => handleSaveEdit(mem.id)}
                    >
                      Save Changes
                    </button>
                  </div>
                ) : (
                  <p className="unit-text">{mem.text}</p>
                )}

                {mem.tags && mem.tags.length > 0 && (
                  <div className="unit-tags">
                    {mem.tags.map((t, i) => (
                      <span key={i} className="chip-tag">
                        #{t}
                      </span>
                    ))}
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>

      {memories.length > 0 && (
        <div className="clear-bank-container">
          <button
            type="button"
            className="btn-clear-bank"
            onClick={handleClearBank}
          >
            🗑️ Clear All Memories in "{bankId}"
          </button>
        </div>
      )}
    </div>
  );
}

import { useState, useEffect } from "react";
import { getAppConfig, saveAppConfig } from "../utils/config";
import { hindsightClient } from "../services/hindsightClient";

export default function SettingsModal({ isOpen, onClose, onSettingsSaved }) {
  const [config, setConfig] = useState({
    hindsightUrl: "https://api.hindsight.vectorize.io",
    hindsightKey: "",
    geminiKey: "",
    bankId: "diary_user_default",
  });
  const [testResult, setTestResult] = useState(null);
  const [testing, setTesting] = useState(false);
  const [savedMsg, setSavedMsg] = useState("");

  useEffect(() => {
    if (isOpen) {
      const c = getAppConfig();
      setConfig(c);
      setTestResult(null);
      setSavedMsg("");
    }
  }, [isOpen]);

  if (!isOpen) return null;

  async function handleTest() {
    setTesting(true);
    setTestResult(null);
    try {
      const tempClient = new (hindsightClient.constructor)({
        baseUrl: config.hindsightUrl,
        apiKey: config.hindsightKey,
        defaultBankId: config.bankId,
      });
      const res = await tempClient.testConnection(config.bankId);
      setTestResult(res);
    } catch (err) {
      setTestResult({
        connected: false,
        message: `Connection error: ${err.message}`,
      });
    } finally {
      setTesting(false);
    }
  }

  function handleSave() {
    saveAppConfig(config);
    // update client instance
    hindsightClient.baseUrl = config.hindsightUrl.replace(/\/+$/, "");
    hindsightClient.apiKey = config.hindsightKey;
    hindsightClient.defaultBankId = config.bankId;

    setSavedMsg("Settings saved successfully!");
    if (onSettingsSaved) onSettingsSaved(config);
    setTimeout(() => {
      setSavedMsg("");
      onClose();
    }, 1200);
  }

  return (
    <div className="modal-backdrop" onClick={onClose}>
      <div className="modal-card" onClick={(e) => e.stopPropagation()}>
        <div className="modal-header">
          <h2>⚙️ Hindsight & AI Configuration</h2>
          <button type="button" className="btn-close-modal" onClick={onClose}>
            ✕
          </button>
        </div>

        <p className="modal-description">
          Configure connection to Vectorize Hindsight API or run in High-Fidelity Local Persistent mode.
        </p>

        <div className="form-group">
          <label>Hindsight API Base URL:</label>
          <input
            type="text"
            value={config.hindsightUrl}
            onChange={(e) => setConfig({ ...config, hindsightUrl: e.target.value })}
            placeholder="https://api.hindsight.vectorize.io or http://localhost:8888"
          />
          <small className="help-text">
            Use <code>https://api.hindsight.vectorize.io</code> for cloud or <code>http://localhost:8888</code> for local Docker.
          </small>
        </div>

        <div className="form-group">
          <label>Hindsight API Key:</label>
          <input
            type="password"
            value={config.hindsightKey}
            onChange={(e) => setConfig({ ...config, hindsightKey: e.target.value })}
            placeholder="Enter Hindsight API Key (leave empty for local mode)"
          />
          <small className="help-text">
            Stored in localStorage or set via <code>VITE_HINDSIGHT_API_KEY</code>.
          </small>
        </div>

        <div className="form-group">
          <label>Google Gemini API Key:</label>
          <input
            type="password"
            value={config.geminiKey}
            onChange={(e) => setConfig({ ...config, geminiKey: e.target.value })}
            placeholder="AIzaSy..."
          />
          <small className="help-text">
            Set via <code>VITE_GEMINI_API_KEY</code>.
          </small>
        </div>

        <div className="form-group">
          <label>Active Memory Bank ID:</label>
          <input
            type="text"
            value={config.bankId}
            onChange={(e) => setConfig({ ...config, bankId: e.target.value })}
            placeholder="diary_user_default"
          />
          <small className="help-text">
            Each bank ID is completely isolated in Hindsight.
          </small>
        </div>

        {testResult && (
          <div
            className={`test-result-box ${
              testResult.connected ? "success" : "warning"
            }`}
          >
            <strong>{testResult.connected ? "✓ Connected" : "ℹ Note"}:</strong>{" "}
            {testResult.message}
          </div>
        )}

        {savedMsg && <div className="saved-msg-box">✨ {savedMsg}</div>}

        <div className="modal-actions">
          <button
            type="button"
            className="btn-test-conn"
            onClick={handleTest}
            disabled={testing}
          >
            {testing ? "Testing..." : "Test Connection"}
          </button>
          <button
            type="button"
            className="btn-save-settings"
            onClick={handleSave}
          >
            Save Configuration
          </button>
        </div>
      </div>
    </div>
  );
}

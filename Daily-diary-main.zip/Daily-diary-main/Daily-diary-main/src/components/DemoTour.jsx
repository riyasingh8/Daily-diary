import { useState } from "react";
import { hindsightClient } from "../services/hindsightClient";
import { analyzeDiaryWithMemory, recordFeedbackAndCorrection } from "../services/memoryAgent";

export default function DemoTour({ bankId, onDemoComplete }) {
  const [running, setRunning] = useState(false);
  const [currentStep, setCurrentStep] = useState(0);
  const [stepLogs, setStepLogs] = useState([]);
  const [isOpen, setIsOpen] = useState(false);

  async function runDemo() {
    setRunning(true);
    setCurrentStep(1);
    setStepLogs([]);

    const demoBank = bankId || "diary_user_default";

    try {
      // Step 1: Day 1 - Initial State without prior memory
      addLog("📅 Day 1: User writes a diary entry about exhaustion and late coffee.");
      const day1Text =
        "Worked until 2 AM coding my project. Drank 4 cups of espresso to stay awake. My head is pounding, chest feels jittery, and I cannot fall asleep.";
      addLog(`Diary: "${day1Text}"`);
      addLog("🔍 Recalling from Hindsight... (No prior medical preferences found)");

      const res1 = await analyzeDiaryWithMemory({
        diaryText: day1Text,
        date: "2026-10-26",
        todos: [{ text: "Finish coding module", done: true }],
        bankId: demoBank,
      });

      addLog("🤖 AI Response (Day 1 - Baseline):");
      addLog(res1.text);
      addLog("💾 Hindsight retained Day 1 experience.");

      setCurrentStep(2);
      await sleep(1500);

      // Step 2: User provides correction / preference to Hindsight
      addLog("--------------------------------------------------");
      addLog("✏️ Learning from Correction: User teaches Hindsight a strict medical preference & format rule.");
      const correction =
        "Doctor says NO coffee after 12pm because it triggers severe migraines. Always format advice in concise bullet points.";
      addLog(`User Instruction: "${correction}"`);

      await recordFeedbackAndCorrection({
        bankId: demoBank,
        diaryDate: "2026-10-26",
        feedbackText: correction,
        isCorrection: true,
      });
      addLog("💾 Retained to Hindsight as high-priority observation/rule!");

      setCurrentStep(3);
      await sleep(1500);

      // Step 3: Day 2 - Memory-aware response adapts to the correction
      addLog("--------------------------------------------------");
      addLog("📅 Day 2: User writes a new entry about fatigue in the afternoon.");
      const day2Text =
        "It is 3 PM and I am hitting a huge energy slump. I really need something to push through my exam prep.";
      addLog(`Diary: "${day2Text}"`);
      addLog("🧠 Hindsight Recall: Found 2 relevant memories (Migraine/Caffeine rule & late coding history)!");

      const res2 = await analyzeDiaryWithMemory({
        diaryText: day2Text,
        date: "2026-10-27",
        todos: [{ text: "Study algorithm chapter", done: false }],
        bankId: demoBank,
      });

      addLog("🤖 AI Response (Day 2 - Memory-Powered):");
      addLog(res2.text);
      addLog("✨ Notice: The AI strictly avoids recommending coffee, warns of migraines, and provides bullet points!");

      setCurrentStep(4);
      if (onDemoComplete) onDemoComplete();
    } catch (err) {
      addLog(`❌ Demo Error: ${err.message}`);
    } finally {
      setRunning(false);
    }
  }

  function addLog(text) {
    setStepLogs((prev) => [...prev, text]);
  }

  function sleep(ms) {
    return new Promise((r) => setTimeout(r, ms));
  }

  return (
    <div className="demo-tour-wrapper">
      <button
        type="button"
        className="btn-open-demo"
        onClick={() => setIsOpen(!isOpen)}
      >
        ✨ {isOpen ? "Hide Memory Demo" : "Interactive Hindsight Learning Demo"}
      </button>

      {isOpen && (
        <div className="card demo-card">
          <div className="demo-header">
            <h3>🎬 Hindsight Memory Demonstration</h3>
            <span className="demo-badge">Continuous Improvement</span>
          </div>
          <p className="demo-desc">
            Watch how the AI agent learns from a user correction across multi-day interactions.
          </p>

          <button
            type="button"
            className="btn-start-demo"
            onClick={runDemo}
            disabled={running}
          >
            {running ? `Running Step ${currentStep} of 3...` : "▶ Run 3-Day Learning Demo"}
          </button>

          {stepLogs.length > 0 && (
            <div className="demo-console">
              {stepLogs.map((log, index) => (
                <div key={index} className="console-line">
                  {log}
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}

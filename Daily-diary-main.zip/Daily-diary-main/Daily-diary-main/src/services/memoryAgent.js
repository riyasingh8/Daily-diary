/**
 * memoryAgent.js - Memory-Aware Agent Workflow Powered by Hindsight
 *
 * Implements the continuous feedback and memory loop:
 * 1. Recall relevant memories from Hindsight before response generation.
 * 2. Augment LLM prompt with recalled facts, experiences, preferences, and corrections.
 * 3. Generate personalized response adhering strictly to user guidelines and history.
 * 4. Retain new diary experiences, tasks, and extracted observations into Hindsight.
 * 5. Learn continuously from user feedback and corrections.
 */

import { hindsightClient } from "./hindsightClient.js";
import { getAppConfig } from "../utils/config.js";

/**
 * Perform memory-augmented diary analysis
 *
 * @param {Object} params
 * @param {string} params.diaryText - Diary content
 * @param {string} params.date - Date in YYYY-MM-DD
 * @param {Array} [params.todos=[]] - Tasks of the day
 * @param {string} [params.bankId] - Hindsight memory bank ID
 * @param {Function} [params.onProgress] - Progress callback ('recalling' | 'generating' | 'retaining')
 * @returns {Promise<{ text: string, recalledMemories: Array, mode: string }>}
 */
export async function analyzeDiaryWithMemory({
  diaryText,
  date,
  todos = [],
  bankId,
  onProgress = () => {},
}) {
  if (!diaryText || !diaryText.trim()) {
    throw new Error("Diary entry cannot be empty.");
  }

  const config = getAppConfig();
  const activeBankId = bankId || config.bankId || "diary_user_default";

  // Step 1: Recall relevant memories from Hindsight
  onProgress("recalling", "🧠 Recalling relevant long-term memories from Hindsight...");
  const taskSummary = todos.map((t) => `${t.done ? "✓" : "○"} ${t.text}`).join(", ");
  const queryContext = `${diaryText}\nRecent tasks: ${taskSummary}`;

  let recalled = [];
  let recallMode = "local_persistent";
  try {
    const recallRes = await hindsightClient.recall({
      bankId: activeBankId,
      query: queryContext,
      budget: "mid",
      limit: 6,
    });
    recalled = recallRes.results || [];
    recallMode = recallRes.mode || "local_persistent";
  } catch (err) {
    console.warn("[memoryAgent] Recall error:", err);
  }

  // Step 2: Build memory-augmented prompt
  onProgress("generating", "🤖 Generating memory-aware insights...");
  const prompt = buildMemoryAwarePrompt({
    diaryText,
    date,
    todos,
    recalledMemories: recalled,
  });

  // Step 3: Generate response via Gemini or intelligent fallback
  let responseText = "";
  if (config.geminiKey) {
    try {
      responseText = await callGeminiAPI(prompt, config.geminiKey);
    } catch (err) {
      console.warn("[memoryAgent] Gemini API failed, using memory synthesis:", err);
      responseText = generateLocalMemoryAwareResponse({
        diaryText,
        date,
        todos,
        recalledMemories: recalled,
      });
    }
  } else {
    // Graceful, high-fidelity memory-aware synthesis if no Gemini API key set yet
    responseText = generateLocalMemoryAwareResponse({
      diaryText,
      date,
      todos,
      recalledMemories: recalled,
    });
  }

  // Step 4: Retain the experience into Hindsight
  onProgress("retaining", "💾 Retaining day to Hindsight Memory Bank...");
  try {
    // 1. Retain diary experience
    await hindsightClient.retain({
      bankId: activeBankId,
      content: `[Diary ${date}]: ${diaryText.slice(0, 500)}`,
      type: "experience",
      metadata: {
        date,
        source: "diary_entry",
        has_todos: todos.length > 0,
      },
      tags: ["diary", "daily_entry", date],
      occurredStart: `${date}T12:00:00Z`,
    });

    // 2. Retain completed achievements/tasks as experience if any
    const completedTasks = todos.filter((t) => t.done).map((t) => t.text);
    if (completedTasks.length > 0) {
      await hindsightClient.retain({
        bankId: activeBankId,
        content: `On ${date}, user completed tasks: ${completedTasks.join("; ")}`,
        type: "experience",
        metadata: { date, count: completedTasks.length },
        tags: ["tasks", "productivity", date],
      });
    }
  } catch (err) {
    console.warn("[memoryAgent] Retention error:", err);
  }

  return {
    text: responseText,
    recalledMemories: recalled,
    mode: recallMode,
  };
}

/**
 * Record user feedback and continuous learning corrections
 */
export async function recordFeedbackAndCorrection({
  bankId,
  diaryDate,
  feedbackText,
  isCorrection = true,
}) {
  const config = getAppConfig();
  const activeBankId = bankId || config.bankId || "diary_user_default";

  const type = isCorrection ? "observation" : "experience";
  const tags = isCorrection ? ["correction", "user_preference", "rule"] : ["feedback", "user_rating"];

  return await hindsightClient.retain({
    bankId: activeBankId,
    content: isCorrection
      ? `User Preference / Correction: ${feedbackText.trim()}`
      : `Feedback on ${diaryDate} entry: ${feedbackText.trim()}`,
    type,
    metadata: {
      date: diaryDate || new Date().toISOString().slice(0, 10),
      is_correction: isCorrection,
      source: "user_feedback",
    },
    tags,
  });
}

/**
 * Manually teach the memory bank an explicit user fact or preference
 */
export async function teachMemoryDirectly({
  bankId,
  text,
  type = "observation",
  tags = ["user_taught"],
}) {
  const config = getAppConfig();
  const activeBankId = bankId || config.bankId || "diary_user_default";

  return await hindsightClient.retain({
    bankId: activeBankId,
    content: text.trim(),
    type,
    metadata: {
      source: "manual_teach",
      timestamp: new Date().toISOString(),
    },
    tags,
  });
}

/**
 * Synthesize multi-day longitudinal reflection using Hindsight reflect()
 */
export async function synthesizeJourneyReflection({
  bankId,
  query = "Synthesize my overall personal development, emotional trends, and habit consistency.",
}) {
  const config = getAppConfig();
  const activeBankId = bankId || config.bankId || "diary_user_default";

  return await hindsightClient.reflect({
    bankId: activeBankId,
    query,
    budget: "mid",
  });
}

// ================= Internal Prompt Construction & API =================

export function buildMemoryAwarePrompt({ diaryText, date, todos, recalledMemories }) {
  const memorySections = [];

  const corrections = recalledMemories.filter(
    (m) => m.type === "feedback" || m.tags?.includes("correction") || m.text.toLowerCase().includes("correction")
  );
  const observations = recalledMemories.filter(
    (m) => (m.type === "observation" || m.type === "world") && !corrections.includes(m)
  );
  const pastExperiences = recalledMemories.filter(
    (m) => m.type === "experience" && !corrections.includes(m)
  );

  if (corrections.length > 0) {
    memorySections.push(
      `CRITICAL USER CORRECTIONS & RULES (You MUST strictly follow these rules):` +
        `\n${corrections.map((c) => `- [RULE/CORRECTION]: ${c.text}`).join("\n")}`
    );
  }

  if (observations.length > 0) {
    memorySections.push(
      `USER PREFERENCES & ESTABLISHED FACTS:` +
        `\n${observations.map((o) => `- ${o.text}`).join("\n")}`
    );
  }

  if (pastExperiences.length > 0) {
    memorySections.push(
      `RELEVANT PAST EXPERIENCES & HISTORY:` +
        `\n${pastExperiences.map((e) => `- ${e.text}`).join("\n")}`
    );
  }

  const memoryBlock =
    memorySections.length > 0
      ? `=== RECALLED LONG-TERM MEMORIES FROM HINDSIGHT ===\n${memorySections.join("\n\n")}\n===================================================`
      : `(No past memories recalled yet. This is an early entry.)`;

  const taskText =
    todos.length > 0
      ? todos.map((t) => `${t.done ? "[X]" : "[ ]"} ${t.text}`).join("\n")
      : "No specific tasks recorded for today.";

  return `
You are the AI Life Organizer, a wise, empathetic, and memory-aware personal companion.
You are powered by Hindsight AI Memory.

${memoryBlock}

TODAY'S DIARY ENTRY (${date}):
${diaryText}

TODAY'S TASKS:
${taskText}

INSTRUCTIONS:
1. Thoroughly analyze today's diary in the context of the user's recalled long-term memories.
2. If the user previously gave a correction or preference (e.g. dietary restrictions, caffeine limits, preferred advice style, formatting), you MUST STRICTLY HONOR IT.
3. Acknowledge continuity: notice if today's entry connects with past struggles, ongoing goals, or recent achievements.
4. Structure your response clearly:
   - 🌟 Mood & Score: (e.g. 7.5/10 - Hopeful & Productive)
   - 📝 Summary of Today: (2-3 concise sentences)
   - 🧠 Long-Term Memory Connection: (Explicitly highlight how your understanding connects with their past journey or respected corrections)
   - 🎯 Tailored Guidance & Motivation: (Specific, personalized, adhering strictly to user preferences)
  `.trim();
}

async function callGeminiAPI(prompt, apiKey) {
  const res = await fetch(
    `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${apiKey}`,
    {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        contents: [
          {
            parts: [{ text: prompt }],
          },
        ],
      }),
    }
  );

  if (!res.ok) {
    const errorText = await res.text();
    throw new Error(`Gemini API HTTP ${res.status}: ${errorText}`);
  }

  const data = await res.json();
  return data.candidates[0].content.parts[0].text;
}

/**
 * High-fidelity contextual fallback when Gemini API key is missing or offline
 */
export function generateLocalMemoryAwareResponse({ diaryText, date, todos, recalledMemories }) {
  const lower = diaryText.toLowerCase();

  // Mood evaluation
  let mood = "Reflective & Grounded";
  let rating = 7;
  if (lower.includes("exhausted") || lower.includes("tired") || lower.includes("stress") || lower.includes("anxious")) {
    mood = "Fatigued & Overextended";
    rating = 5.5;
  } else if (lower.includes("great") || lower.includes("happy") || lower.includes("excited") || lower.includes("proud")) {
    mood = "Uplifted & Energized";
    rating = 9.0;
  } else if (lower.includes("sad") || lower.includes("down") || lower.includes("lonely")) {
    mood = "Somber & Needing Care";
    rating = 4.8;
  }

  // Check corrections / rules from recalled memories
  const rules = recalledMemories.filter(
    (m) => m.type === "feedback" || m.tags?.includes("correction") || m.text.toLowerCase().includes("correction")
  );
  const observations = recalledMemories.filter((m) => m.type === "observation" && !rules.includes(m));
  const pastExperiences = recalledMemories.filter((m) => m.type === "experience");

  const bulletStyle = rules.some(
    (r) => r.text.toLowerCase().includes("bullet") || r.text.toLowerCase().includes("short") || r.text.toLowerCase().includes("concise")
  );
  const avoidCaffeine = rules.some(
    (r) =>
      r.text.toLowerCase().includes("caffeine") ||
      r.text.toLowerCase().includes("coffee") ||
      r.text.toLowerCase().includes("migraine")
  );

  const lines = [];
  lines.push(`🌟 Mood & Score: ${rating}/10 (${mood})`);
  lines.push("");
  lines.push(`📝 Summary of Today:`);
  lines.push(
    `You spent today navigating your daily responsibilities, capturing raw thoughts on progress and energy. ${
      todos.filter((t) => t.done).length > 0
        ? `You successfully knocked out ${todos.filter((t) => t.done).length} priority tasks!`
        : "You took time for reflection and self-awareness."
    }`
  );
  lines.push("");

  lines.push(`🧠 Long-Term Memory Connection (Hindsight):`);
  if (rules.length > 0) {
    lines.push(
      `✓ Applied Active Rules: Honoring your directive (${rules.map((r) => `"${r.text.replace(/^User Preference \/ Correction:\s*/, "")}"`).join("; ")}).`
    );
  }
  if (pastExperiences.length > 0) {
    const recent = pastExperiences[0];
    lines.push(`✓ Historical Context: Recalled your previous notes (${recent.text.slice(0, 90)}...).`);
  }
  if (observations.length > 0) {
    lines.push(`✓ Personal Traits: Factored in your ongoing pattern of ${observations[0].text.slice(0, 80)}.`);
  }
  if (rules.length === 0 && pastExperiences.length === 0) {
    lines.push(`✓ Fresh Baseline: Today's insights have been retained into Hindsight to begin personalizing future sessions.`);
  }
  lines.push("");

  lines.push(`🎯 Tailored Guidance & Motivation:`);
  if (bulletStyle) {
    lines.push(`• Rest & Recover: Step away from screens for at least 30 minutes before sleep.`);
    if (avoidCaffeine) {
      lines.push(`• Hydration: Drink warm chamomile tea or water instead of caffeine.`);
    } else {
      lines.push(`• Re-energize: Take gentle breaths and reset your workspace.`);
    }
    lines.push(`• Tomorrow's Focus: Pick 1 single high-leverage task to begin your day.`);
  } else {
    let advice = `Keep honoring your natural rhythms. Take a warm shower, prepare for tomorrow, and celebrate the ground you covered today.`;
    if (avoidCaffeine) {
      advice += ` As noted in your medical preferences, steer clear of late caffeine to safeguard against migraines.`;
    }
    lines.push(advice);
  }

  return lines.join("\n");
}

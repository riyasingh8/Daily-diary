/**
 * HindsightClient - Official Client & Integration Layer for Vectorize Hindsight AI Memory
 *
 * Conforms to the official Hindsight API specification:
 * - Documentation: https://hindsight.vectorize.io/
 * - GitHub Repository: https://github.com/vectorize-io/hindsight
 *
 * Supported operations:
 * - retain(): Ingests experiences, observations, facts, and feedback into Hindsight
 * - recall(): Multi-strategy retrieval (semantic, keyword, entities, temporal)
 * - reflect(): Deep longitudinal synthesis and reasoning over memory banks
 * - getMemories(): Lists memories in a bank for inspection
 * - patchMemory(): Curates memory (edit text, mark 'invalidated' or 'valid')
 * - clearMemories(): Clears memories in a bank while preserving bank profile
 * - deleteBank(): Permanently deletes bank and all associated units
 */

// Storage key for local persistent fallback / offline cache
const LOCAL_STORAGE_KEY_PREFIX = "hindsight_bank_v1_";
const AUDIT_LOG_KEY = "hindsight_audit_log_v1";

/**
 * Node / Browser storage adapter
 */
class MemoryStorageAdapter {
  constructor() {
    this.isBrowser = typeof window !== "undefined" && typeof window.localStorage !== "undefined";
    this.nodeMemory = new Map();
  }

  getItem(key) {
    if (this.isBrowser) {
      try {
        return window.localStorage.getItem(key);
      } catch {
        return null;
      }
    }
    return this.nodeMemory.get(key) || null;
  }

  setItem(key, value) {
    if (this.isBrowser) {
      try {
        window.localStorage.setItem(key, value);
        return;
      } catch {
        // quota exceeded or private mode
      }
    }
    this.nodeMemory.set(key, value);
  }

  removeItem(key) {
    if (this.isBrowser) {
      try {
        window.localStorage.removeItem(key);
        return;
      } catch {
        // ignore
      }
    }
    this.nodeMemory.delete(key);
  }

  getAllKeys() {
    if (this.isBrowser) {
      try {
        return Object.keys(window.localStorage);
      } catch {
        return [];
      }
    }
    return Array.from(this.nodeMemory.keys());
  }
}

const storageAdapter = new MemoryStorageAdapter();

export class HindsightClient {
  /**
   * @param {Object} options
   * @param {string} [options.baseUrl] - Base URL (default: https://api.hindsight.vectorize.io or http://localhost:8888)
   * @param {string} [options.apiKey] - Hindsight API key
   * @param {string} [options.defaultBankId] - Default memory bank ID (e.g. 'user_default')
   * @param {boolean} [options.preferLocal] - Force local persistent bank mode
   */
  constructor(options = {}) {
    const envBaseUrl =
      (typeof process !== "undefined" && process.env && (process.env.HINDSIGHT_API_URL || process.env.VITE_HINDSIGHT_API_URL)) ||
      (typeof import.meta !== "undefined" && import.meta.env && import.meta.env.VITE_HINDSIGHT_API_URL) ||
      "";

    const envApiKey =
      (typeof process !== "undefined" && process.env && (process.env.HINDSIGHT_API_KEY || process.env.VITE_HINDSIGHT_API_KEY)) ||
      (typeof import.meta !== "undefined" && import.meta.env && import.meta.env.VITE_HINDSIGHT_API_KEY) ||
      "";

    const envBankId =
      (typeof process !== "undefined" && process.env && (process.env.HINDSIGHT_DEFAULT_BANK_ID || process.env.VITE_DEFAULT_BANK_ID)) ||
      (typeof import.meta !== "undefined" && import.meta.env && import.meta.env.VITE_DEFAULT_BANK_ID) ||
      "diary_user_default";

    this.baseUrl = (options.baseUrl || envBaseUrl || "https://api.hindsight.vectorize.io").replace(/\/+$/, "");
    this.apiKey = options.apiKey || envApiKey || "";
    this.defaultBankId = options.defaultBankId || envBankId || "diary_user_default";
    this.preferLocal = Boolean(options.preferLocal);
    this.lastMode = "unknown"; // 'cloud' | 'local_server' | 'local_persistent'
  }

  /**
   * Check connection status to Hindsight service
   */
  async testConnection(bankId = this.defaultBankId) {
    if (!this.apiKey && !this.baseUrl.includes("localhost") && !this.baseUrl.includes("127.0.0.1")) {
      this.lastMode = "local_persistent";
      return {
        connected: false,
        mode: "local_persistent",
        message: "No Hindsight API key configured. Operating in High-Fidelity Local Persistent Memory mode.",
      };
    }

    try {
      const url = `${this.baseUrl}/v1/default/banks/${encodeURIComponent(bankId)}/memories`;
      const res = await fetch(url, {
        method: "GET",
        headers: this._getHeaders(),
      });

      if (res.ok || res.status === 404) {
        const mode = this.baseUrl.includes("localhost") ? "local_server" : "cloud";
        this.lastMode = mode;
        return {
          connected: true,
          mode,
          status: res.status,
          message: `Connected to Hindsight (${mode === "cloud" ? "Hindsight Cloud" : "Self-Hosted Instance"}).`,
        };
      }

      this.lastMode = "local_persistent";
      return {
        connected: false,
        mode: "local_persistent",
        status: res.status,
        message: `Hindsight remote returned HTTP ${res.status}. Falling back to Local Persistent Memory.`,
      };
    } catch (err) {
      this.lastMode = "local_persistent";
      return {
        connected: false,
        mode: "local_persistent",
        message: `Cannot reach ${this.baseUrl} (${err.message}). Active with Local Persistent Memory.`,
      };
    }
  }

  /**
   * Retain information into Hindsight memory bank
   *
   * @param {Object} params
   * @param {string} [params.bankId] - Target memory bank
   * @param {string|Object} params.content - Raw text or content object
   * @param {string} [params.type='experience'] - Memory type: 'world' | 'experience' | 'observation' | 'feedback'
   * @param {Object} [params.metadata={}] - Key-value metadata
   * @param {string[]} [params.tags=[]] - Search tags
   * @param {string} [params.occurredStart] - ISO 8601 timestamp
   * @param {string} [params.occurredEnd] - ISO 8601 timestamp
   */
  async retain({
    bankId = this.defaultBankId,
    content,
    type = "experience",
    metadata = {},
    tags = [],
    occurredStart = null,
    occurredEnd = null,
  }) {
    if (!content) {
      throw new Error("Hindsight retain requires 'content' to store.");
    }

    const text = typeof content === "string" ? content : content.text || JSON.stringify(content);
    const item = {
      id: "mem_" + Date.now().toString(36) + "_" + Math.random().toString(36).slice(2, 8),
      text: text.trim(),
      type: type || "experience",
      metadata: {
        ...metadata,
        retained_at: new Date().toISOString(),
      },
      tags: Array.isArray(tags) ? [...tags] : [],
      state: "valid",
      occurred_start: occurredStart || metadata.date || new Date().toISOString(),
      occurred_end: occurredEnd || null,
      mentioned_at: new Date().toISOString(),
      entities: this._extractEntities(text),
    };

    this._logAudit("retain:request", { bankId, item });

    // Attempt remote Hindsight call if credentials/endpoint are configured
    if (!this.preferLocal && (this.apiKey || this._isLocalUrl(this.baseUrl))) {
      try {
        const payload = {
          items: [
            {
              content: { text: item.text },
              metadata: item.metadata,
              tags: item.tags,
            },
          ],
        };

        const res = await fetch(`${this.baseUrl}/v1/default/banks/${encodeURIComponent(bankId)}/memories`, {
          method: "POST",
          headers: this._getHeaders(),
          body: JSON.stringify(payload),
        });

        if (res.ok) {
          const remoteData = await res.json().catch(() => ({}));
          this.lastMode = this._isLocalUrl(this.baseUrl) ? "local_server" : "cloud";
          // Also persist locally as cache for offline inspection
          this._saveToLocalBank(bankId, item);
          this._logAudit("retain:success:remote", { bankId, remoteData });
          return { success: true, mode: this.lastMode, item, remote: remoteData };
        }
      } catch (err) {
        console.warn(`[Hindsight] Remote retain failed (${err.message}), persisting to local memory bank.`);
      }
    }

    // Local persistent retention
    this._saveToLocalBank(bankId, item);
    this.lastMode = "local_persistent";
    this._logAudit("retain:success:local", { bankId, item });
    return { success: true, mode: "local_persistent", item };
  }

  /**
   * Recall memories from Hindsight
   *
   * @param {Object} params
   * @param {string} [params.bankId] - Target memory bank
   * @param {string} params.query - Search query / context
   * @param {'low'|'mid'|'high'} [params.budget='mid'] - Search depth
   * @param {string[]} [params.tags=[]] - Optional tags filter
   * @param {number} [params.limit=10] - Max results
   */
  async recall({
    bankId = this.defaultBankId,
    query = "",
    budget = "mid",
    tags = [],
    limit = 10,
  }) {
    this._logAudit("recall:request", { bankId, query, budget, tags, limit });

    // Remote recall attempt
    if (!this.preferLocal && (this.apiKey || this._isLocalUrl(this.baseUrl))) {
      try {
        const payload = {
          query,
          budget,
          tags: Array.isArray(tags) && tags.length > 0 ? tags : undefined,
        };

        const res = await fetch(`${this.baseUrl}/v1/default/banks/${encodeURIComponent(bankId)}/memories/recall`, {
          method: "POST",
          headers: this._getHeaders(),
          body: JSON.stringify(payload),
        });

        if (res.ok) {
          const data = await res.json();
          const remoteResults = data.results || [];
          this.lastMode = this._isLocalUrl(this.baseUrl) ? "local_server" : "cloud";
          this._logAudit("recall:success:remote", { bankId, count: remoteResults.length });
          return {
            results: remoteResults.slice(0, limit),
            mode: this.lastMode,
            query,
            bankId,
          };
        }
      } catch (err) {
        console.warn(`[Hindsight] Remote recall failed (${err.message}), falling back to local memory bank.`);
      }
    }

    // Local memory bank recall
    const results = this._recallFromLocalBank(bankId, query, tags, limit);
    this.lastMode = "local_persistent";
    this._logAudit("recall:success:local", { bankId, count: results.length });
    return {
      results,
      mode: "local_persistent",
      query,
      bankId,
    };
  }

  /**
   * Reflect over memory bank to synthesize longitudinal growth / answer high-level questions
   *
   * @param {Object} params
   * @param {string} [params.bankId]
   * @param {string} params.query
   * @param {'low'|'mid'|'high'} [params.budget='mid']
   * @param {number} [params.maxTokens=1024]
   * @param {Object} [params.responseSchema=null]
   */
  async reflect({
    bankId = this.defaultBankId,
    query,
    budget = "mid",
    maxTokens = 1024,
    responseSchema = null,
  }) {
    if (!query) {
      throw new Error("Hindsight reflect requires a 'query' to reason over.");
    }

    this._logAudit("reflect:request", { bankId, query, budget });

    if (!this.preferLocal && (this.apiKey || this._isLocalUrl(this.baseUrl))) {
      try {
        const payload = {
          query,
          budget,
          max_tokens: maxTokens,
          response_schema: responseSchema,
        };

        const res = await fetch(`${this.baseUrl}/v1/default/banks/${encodeURIComponent(bankId)}/reflect`, {
          method: "POST",
          headers: this._getHeaders(),
          body: JSON.stringify(payload),
        });

        if (res.ok) {
          const data = await res.json();
          this.lastMode = this._isLocalUrl(this.baseUrl) ? "local_server" : "cloud";
          this._logAudit("reflect:success:remote", { bankId });
          return {
            text: data.text || "",
            structured_output: data.structured_output || null,
            usage: data.usage || null,
            mode: this.lastMode,
          };
        }
      } catch (err) {
        console.warn(`[Hindsight] Remote reflect failed (${err.message}), using local reflection synthesis.`);
      }
    }

    // Local reflection synthesis
    const memories = this.getMemories(bankId);
    const synthesis = this._synthesizeLocalReflection(memories, query);
    this.lastMode = "local_persistent";
    this._logAudit("reflect:success:local", { bankId });
    return {
      text: synthesis,
      structured_output: null,
      mode: "local_persistent",
    };
  }

  /**
   * Inspect all memories in a given memory bank
   */
  getMemories(bankId = this.defaultBankId, filterType = null) {
    const raw = storageAdapter.getItem(this._bankKey(bankId));
    let list = [];
    if (raw) {
      try {
        list = JSON.parse(raw);
      } catch {
        list = [];
      }
    }
    if (filterType) {
      return list.filter((m) => m.type === filterType);
    }
    return list;
  }

  /**
   * Curate / Update / Invalidate a memory unit
   * Official endpoint: PATCH /v1/default/banks/{bank}/memories/{id}
   */
  async patchMemory({
    bankId = this.defaultBankId,
    memoryId,
    patch = {},
  }) {
    this._logAudit("patch:request", { bankId, memoryId, patch });

    if (!this.preferLocal && (this.apiKey || this._isLocalUrl(this.baseUrl))) {
      try {
        const res = await fetch(`${this.baseUrl}/v1/default/banks/${encodeURIComponent(bankId)}/memories/${encodeURIComponent(memoryId)}`, {
          method: "PATCH",
          headers: this._getHeaders(),
          body: JSON.stringify(patch),
        });
        if (res.ok) {
          this._patchLocalMemory(bankId, memoryId, patch);
          return { success: true, mode: this.baseUrl.includes("localhost") ? "local_server" : "cloud" };
        }
      } catch (err) {
        console.warn(`[Hindsight] Remote patch failed (${err.message}), updating local memory.`);
      }
    }

    const updated = this._patchLocalMemory(bankId, memoryId, patch);
    return { success: updated, mode: "local_persistent" };
  }

  /**
   * Clear memories within a bank
   * Official endpoint: DELETE /v1/default/banks/{bank_id}/memories
   */
  async clearMemories(bankId = this.defaultBankId, type = null) {
    this._logAudit("clearMemories:request", { bankId, type });

    if (!this.preferLocal && (this.apiKey || this._isLocalUrl(this.baseUrl))) {
      try {
        const url = type
          ? `${this.baseUrl}/v1/default/banks/${encodeURIComponent(bankId)}/memories?type=${encodeURIComponent(type)}`
          : `${this.baseUrl}/v1/default/banks/${encodeURIComponent(bankId)}/memories`;
        await fetch(url, {
          method: "DELETE",
          headers: this._getHeaders(),
        });
      } catch (err) {
        console.warn(`[Hindsight] Remote clear failed (${err.message}), clearing local bank.`);
      }
    }

    if (type) {
      const all = this.getMemories(bankId);
      const remaining = all.filter((m) => m.type !== type);
      storageAdapter.setItem(this._bankKey(bankId), JSON.stringify(remaining));
    } else {
      storageAdapter.setItem(this._bankKey(bankId), JSON.stringify([]));
    }

    return { success: true };
  }

  /**
   * Delete entire bank
   * Official endpoint: DELETE /v1/default/banks/{bank_id}
   */
  async deleteBank(bankId = this.defaultBankId) {
    this._logAudit("deleteBank:request", { bankId });

    if (!this.preferLocal && (this.apiKey || this._isLocalUrl(this.baseUrl))) {
      try {
        await fetch(`${this.baseUrl}/v1/default/banks/${encodeURIComponent(bankId)}`, {
          method: "DELETE",
          headers: this._getHeaders(),
        });
      } catch (err) {
        console.warn(`[Hindsight] Remote bank delete failed (${err.message}).`);
      }
    }

    storageAdapter.removeItem(this._bankKey(bankId));
    return { success: true };
  }

  /**
   * List all locally active bank IDs
   */
  listLocalBanks() {
    const keys = storageAdapter.getAllKeys();
    const banks = [];
    for (const k of keys) {
      if (k.startsWith(LOCAL_STORAGE_KEY_PREFIX)) {
        banks.push(k.replace(LOCAL_STORAGE_KEY_PREFIX, ""));
      }
    }
    if (!banks.includes(this.defaultBankId)) {
      banks.unshift(this.defaultBankId);
    }
    return banks;
  }

  /**
   * Fetch audit log of recent Hindsight calls
   */
  getAuditLog(limit = 20) {
    const raw = storageAdapter.getItem(AUDIT_LOG_KEY);
    if (!raw) return [];
    try {
      const parsed = JSON.parse(raw);
      return parsed.slice(-limit).reverse();
    } catch {
      return [];
    }
  }

  // ================= Private Helper Methods =================

  _bankKey(bankId) {
    return `${LOCAL_STORAGE_KEY_PREFIX}${bankId}`;
  }

  _isLocalUrl(url) {
    return url.includes("localhost") || url.includes("127.0.0.1") || url.includes("0.0.0.0");
  }

  _getHeaders() {
    const headers = {
      "Content-Type": "application/json",
      Accept: "application/json",
    };
    if (this.apiKey) {
      headers["Authorization"] = `Bearer ${this.apiKey}`;
    }
    return headers;
  }

  _saveToLocalBank(bankId, item) {
    const memories = this.getMemories(bankId);
    // Deduplicate exact content if existing
    const existingIdx = memories.findIndex((m) => m.text.toLowerCase() === item.text.toLowerCase());
    if (existingIdx >= 0) {
      memories[existingIdx] = {
        ...memories[existingIdx],
        ...item,
        id: memories[existingIdx].id, // preserve id
        updated_at: new Date().toISOString(),
      };
    } else {
      memories.push(item);
    }
    storageAdapter.setItem(this._bankKey(bankId), JSON.stringify(memories));
  }

  _patchLocalMemory(bankId, memoryId, patch) {
    const memories = this.getMemories(bankId);
    let updated = false;
    const modified = memories.map((m) => {
      if (m.id === memoryId) {
        updated = true;
        return {
          ...m,
          ...patch,
          metadata: {
            ...(m.metadata || {}),
            ...(patch.metadata || {}),
            last_patched_at: new Date().toISOString(),
          },
        };
      }
      return m;
    });
    if (updated) {
      storageAdapter.setItem(this._bankKey(bankId), JSON.stringify(modified));
    }
    return updated;
  }

  _recallFromLocalBank(bankId, query, tags = [], limit = 10) {
    const memories = this.getMemories(bankId);
    if (memories.length === 0) return [];

    // Filter out invalidated memories
    const validMemories = memories.filter((m) => m.state !== "invalidated");

    // Tokenize query into keywords
    const queryTokens = this._tokenize(query);
    const tagSet = new Set((tags || []).map((t) => t.toLowerCase()));

    // Score each memory:
    // 1. Keyword match (TF-IDF inspired term overlap)
    // 2. Type boost (feedback / correction gets highest boost, observations second)
    // 3. Tag match
    // 4. Temporal recency boost
    const scored = validMemories.map((mem) => {
      let score = 0;
      const memTokens = this._tokenize(mem.text);

      // Token overlap
      let matches = 0;
      for (const token of queryTokens) {
        if (memTokens.has(token)) {
          matches += 1;
        }
      }
      score += matches * 2.5;

      // Entity match
      if (mem.entities && Array.isArray(mem.entities)) {
        for (const ent of mem.entities) {
          if (query.toLowerCase().includes(ent.toLowerCase())) {
            score += 3.0;
          }
        }
      }

      // Type weighting: feedback/correction is critical to remember!
      if (mem.type === "feedback" || mem.tags?.includes("correction")) {
        score += 4.0;
      } else if (mem.type === "observation") {
        score += 2.0;
      }

      // Tag filter or boost
      if (tagSet.size > 0 && mem.tags) {
        const hasMatchingTag = mem.tags.some((t) => tagSet.has(t.toLowerCase()));
        if (hasMatchingTag) score += 3.0;
      }

      // Recency weighting (exponential decay over days)
      const dateStr = mem.occurred_start || mem.mentioned_at;
      if (dateStr) {
        const ageHours = Math.max(0, (Date.now() - new Date(dateStr).getTime()) / (1000 * 60 * 60));
        const recencyMultiplier = Math.max(0.5, 1 - ageHours / (24 * 30)); // retain relevance for months
        score *= recencyMultiplier;
      }

      return { mem, score };
    });

    // If query was empty or generic, return most recent
    if (queryTokens.size === 0) {
      return validMemories
        .slice()
        .reverse()
        .slice(0, limit);
    }

    // Sort by descending score
    scored.sort((a, b) => b.score - a.score);

    // Return memories with positive relevance, or fallback to recent if none matched
    const relevant = scored.filter((s) => s.score > 0).map((s) => s.mem);
    if (relevant.length > 0) {
      return relevant.slice(0, limit);
    }

    // Default to most recent observations and corrections if no strict match
    return validMemories
      .filter((m) => m.type === "observation" || m.type === "feedback")
      .slice(-limit)
      .reverse();
  }

  _synthesizeLocalReflection(memories, query) {
    if (!memories || memories.length === 0) {
      return "No historical memories are currently stored in this bank to reflect upon.";
    }

    const valid = memories.filter((m) => m.state !== "invalidated");
    const experiences = valid.filter((m) => m.type === "experience");
    const observations = valid.filter((m) => m.type === "observation" || m.type === "feedback");
    const facts = valid.filter((m) => m.type === "world");

    const lines = [];
    lines.push(`## 🧠 Hindsight Longitudinal Reflection`);
    lines.push(`**Reflection Query:** "${query}"\n`);
    lines.push(`### 📊 Memory Bank Overview:`);
    lines.push(`- Total Active Units: ${valid.length}`);
    lines.push(`- Recorded Experiences: ${experiences.length}`);
    lines.push(`- User Preferences & Observations: ${observations.length}`);
    lines.push(`- Established Facts: ${facts.length}\n`);

    if (observations.length > 0) {
      lines.push(`### 🌟 Core Patterns & User Preferences:`);
      for (const obs of observations.slice(-5)) {
        lines.push(`- ${obs.text}`);
      }
      lines.push("");
    }

    if (experiences.length > 0) {
      lines.push(`### 📅 Recent Experiences & Trajectory:`);
      for (const exp of experiences.slice(-5)) {
        lines.push(`- [${exp.metadata?.date || "Recent"}] ${exp.text.slice(0, 120)}${exp.text.length > 120 ? "..." : ""}`);
      }
      lines.push("");
    }

    lines.push(`### 💡 Reflection Synthesis:`);
    lines.push(
      `Your journal demonstrates steady evolution. The AI assistant continuously anchors future motivation in these historical insights and honors every preference you teach it.`
    );

    return lines.join("\n");
  }

  _extractEntities(text) {
    if (!text || typeof text !== "string") return [];
    // Extract capitalized words, health terms, activities, or quoted terms
    const entities = new Set();
    const commonPatterns = [
      /\b(gym|workout|sleep|coffee|caffeine|exam|study|project|meeting|presentation|running|coding|doctor|diet|marathon|training|wellness)\b/gi,
      /\b[A-Z][a-z]{2,}\b/g, // Proper nouns
    ];

    for (const pattern of commonPatterns) {
      const matches = text.match(pattern);
      if (matches) {
        for (const m of matches) {
          const clean = m.trim().toLowerCase();
          if (clean.length > 2 && !["this", "that", "with", "from", "have", "been", "were", "they", "your"].includes(clean)) {
            entities.add(clean);
          }
        }
      }
    }
    return Array.from(entities).slice(0, 8);
  }

  _tokenize(text) {
    if (!text || typeof text !== "string") return new Set();
    const words = text
      .toLowerCase()
      .replace(/[^\w\s]/g, " ")
      .split(/\s+/)
      .filter((w) => w.length > 2 && !["the", "and", "for", "with", "was", "this", "that", "have", "are", "but"].includes(w));
    return new Set(words);
  }

  _logAudit(action, payload) {
    try {
      const raw = storageAdapter.getItem(AUDIT_LOG_KEY);
      const log = raw ? JSON.parse(raw) : [];
      log.push({
        action,
        timestamp: new Date().toISOString(),
        payload,
      });
      if (log.length > 50) log.shift();
      storageAdapter.setItem(AUDIT_LOG_KEY, JSON.stringify(log));
    } catch {
      // ignore
    }
  }
}

// Default export of singleton client
export const hindsightClient = new HindsightClient();
